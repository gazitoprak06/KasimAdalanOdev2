import UIKit


//Soru 1: parametre olarak girilen kilometreyi mile dönüştürdükten sonra geri döndüren bir metod yazınız. Mile = Km x 0.621
class DönüşümHesapla {
    func kmToMiles(km: Double) -> Double {
        return km * 0.621371
    }
}

let hesapla = DönüşümHesapla()
let sonuc = hesapla.kmToMiles(km: 7.6)
print("Dönüşüm sonucu: \(sonuc)")


//Soru 2:kenarları parametre olarak girilen ve geri döndüren dikdörtgenin alanını hesaplayan bir metod yazınız.


class Dikdörtgen {
    func alanHesapla(kisaK: Int, uzunK: Int) -> Int {
        return kisaK * uzunK
    }
}

let dikdörtgenAlanHesaplayı = Dikdörtgen()
let alanHesabi = dikdörtgenAlanHesaplayı.alanHesapla(kisaK: 6, uzunK: 10)
print("Dikdörtgen Alanı: \(alanHesabi)")



//Soru 3: parametre olarak girilen sayının faktoriyel değerini hesaplayıp geri döndüren metodu yazınız.

class Fonksiyonlar3 {
    func faktoriyelHesapla(n: Int) -> Int {
        if n == 0 || n == 1 {
            return 1
        }
        
        var islemSonucu = 1
        var i = 1
        
        while i <= n {
            islemSonucu *= i
            i += 1
        }
        
        return islemSonucu
    
    }
}

let fonksiyonlar = Fonksiyonlar3()
let islemSonucu = fonksiyonlar.faktoriyelHesapla(n: 7)
print("Faktoriyel Hesabı : \(islemSonucu)")


//Soru 4:parametre olarak girilen kelime içinde kaç tane e harfi olduğunu gösteren metod yazınız.

class Harf {
    func eHarfiSayisi(kelime: String) -> Int {
        return kelime.lowercased().filter { $0 == "e" }.count
    }
}

let harfSayisi = Harf()
let eHarfSayisi = harfSayisi.eHarfiSayisi(kelime: "Esma")
print("Girilen kelimedeki e/E harf sayısı: \(eHarfSayisi)")

//Soru 5: parametre olarak girilen kenar sayısına göre her bir iç açıyı hesaplayıp sonucu geri getiren methodu yazın. iç açılar toplamı = ((Kenar sayısı - 2)*180)/kenar sayısı

class Kenar {
    func icAciHesapla(kacKenarli: Int) -> [Int] {
        guard kacKenarli >= 3 else {
            print("Geçersiz kenar sayısı. En az 3 kenarlı bir çokgen gereklidir.")
            return []
        }
        
        let aci = (kacKenarli - 2) * 180
        let herBirIcAci = aci / kacKenarli
        let icAciDizisi = Array(repeating: herBirIcAci, count: kacKenarli)
        
        return icAciDizisi
    }
}

let kenar = Kenar()
let kacKenarli = 8
let icAciDizisi = kenar.icAciHesapla(kacKenarli: kacKenarli)

if !icAciDizisi.isEmpty {
    let toplamIcAci = icAciDizisi.reduce(0, +)
    print("\(kacKenarli)-kenarlı çokgenin iç açıları:")
    for (index, icAci) in icAciDizisi.enumerated() {
        print("Kenar \(index + 1): \(icAci) derece")
    }
    print("Toplam iç açı: \(toplamIcAci) derece")
}


//Soru 6: parametre olarak girilen gün sayısına göre maaş hesabı yapan ve elde edilen değeri döndüren methodu yazınız. 1 günde 8 saat çalışabilir, çalışma saat ücreti; 40 TL, mesai saati ücreti; 80 TL, 150 saat üzeri mesai sayılır.
class MaasHesaplama {
    let calismaSaatlikUcret: Double
    let mesaiSaatlikUcret: Double
    let maksimumMesaiCalismasi: Int
    let hesaplananCalismaSaati: Int
    
    init(calismaSaatlikUcret: Double, mesaiSaatlikUcret: Double, maksimumMesaiCalismasi: Int, hesaplananCalismaSaati: Int) {
        self.calismaSaatlikUcret = calismaSaatlikUcret
        self.mesaiSaatlikUcret = mesaiSaatlikUcret
        self.maksimumMesaiCalismasi = maksimumMesaiCalismasi
        self.hesaplananCalismaSaati = hesaplananCalismaSaati
    }
    
    func maasHesapla(hesaplananGunSayisi: Int) -> Double {
        guard hesaplananGunSayisi > 0 else {
            print("Geçersiz gün sayısı. Pozitif bir değer girin.")
            return 0
        }
        
        var toplamMaas = 0.0
        var calismaSaatiToplam = 0
        
        for _ in 1...hesaplananGunSayisi {
            calismaSaatiToplam += hesaplananCalismaSaati
            
            if calismaSaatiToplam <= maksimumMesaiCalismasi {
                toplamMaas += Double(hesaplananCalismaSaati) * calismaSaatlikUcret
            } else {
                let mesaiSaatleri = calismaSaatiToplam - maksimumMesaiCalismasi
                toplamMaas += Double(hesaplananCalismaSaati - mesaiSaatleri) * calismaSaatlikUcret
                toplamMaas += Double(mesaiSaatleri) * mesaiSaatlikUcret
            }
        }
        
        return toplamMaas
    }
}

let maasHesaplama = MaasHesaplama(calismaSaatlikUcret: 40.0, mesaiSaatlikUcret: 80.0, maksimumMesaiCalismasi: 150, hesaplananCalismaSaati: 8)
let hesaplananGunSayisi = 23
let maas = maasHesaplama.maasHesapla(hesaplananGunSayisi: hesaplananGunSayisi)
print("Toplam maaş: \(maas) TL")


//Soru 7:parametre olarak girilen otopark süresine göre otopark ücreti hesaplayarak geri döndüren methodu yazınız. 1 saat ücreti 50 TL, 1 saat aşımından sonra her saat için 10 TL'dir.

class Otopark {
    let ilkSaatUcreti: Int
    let ekSaatUcreti: Int
    
    init(ilkSaatUcreti: Int, ekSaatUcreti: Int) {
        self.ilkSaatUcreti = ilkSaatUcreti
        self.ekSaatUcreti = ekSaatUcreti
    }
    
    func hesaplaUcret(sure: Int) -> Int {
        guard sure >= 0 else {
            print("Geçersiz süre. Pozitif bir değer girin.")
            return 0
        }
        
        let dakika = sure % 60
        let tamSaatSayisi = sure / 60
        
        var toplamUcret = tamSaatSayisi * ekSaatUcreti
        
        if dakika > 0 {
            toplamUcret += ilkSaatUcreti
        }
        
        return toplamUcret
    }
}

let otopark = Otopark(ilkSaatUcreti: 50, ekSaatUcreti: 10)
let sure = 200 // Süreyi dakika cinsinden belirtin.
let toplamUcret = otopark.hesaplaUcret(sure: sure)
print("Otopark ücreti: \(toplamUcret) TL")

